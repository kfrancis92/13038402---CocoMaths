//
//  Dragging_Image.swift
//  cwkMathApp-13038402
//
//  Created by kf13aal on 21/03/2017.
//  Copyright © 2017 kf13aal. All rights reserved.
//

import UIKit

class Dragging_Image: UIImageView {

    var startLocation: CGPoint?
    
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        
        startLocation = touches.first?.locationInView(self)
        
    }
    
    override func touchesMoved(touches: Set<UITouch>, withEvent event: UIEvent?) {
        
        let currentLocation = touches.first?.locationInView(self)
        let dx = currentLocation!.x - startLocation!.x
        let dy = currentLocation!.y - startLocation!.y
        
        
        
        self.center = CGPointMake(self.center.x+dx, self.center.y+dy)
        
        let xx = CGRectGetMidX(self.bounds)
        self.center.x = max(xx, self.center.x)
        self.center.x = min(self.superview!.bounds.size.width - xx, self.center.x)
        
        let yy = CGRectGetMidY(self.bounds)
        self.center.y = max(yy*30, self.center.y)
        self.center.y = min(self.superview!.bounds.size.height - yy*2, self.center.y)
        
    }

}
