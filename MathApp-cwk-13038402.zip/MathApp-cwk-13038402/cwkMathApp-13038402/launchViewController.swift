//
//  launchViewController.swift
//  cwkMathApp-13038402
//
//  Created by kf13aal on 21/03/2017.
//  Copyright © 2017 kf13aal. All rights reserved.
//

import UIKit

class launchViewController: UIViewController {

    
    @IBOutlet weak var sunGif: UIImageView!
    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        var sunNames = ["s1.png", "s2.png", "s3.png", "s4.png", "s5.png", "s6.png", "s7.png", "s8.png", "s9.png", "s10.png"]
        
        var pics = [UIImage]()
        
        for i in 0..<sunNames.count{
            
            pics.append(UIImage(named: sunNames[i])!)
            
        }
        
        sunGif.animationImages = pics
        sunGif.animationDuration = 1.0
        sunGif.startAnimating()
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
