//
//  resultsViewController.swift
//  cwkMathApp-13038402
//
//  Created by kf13aal on 20/03/2017.
//  Copyright © 2017 kf13aal. All rights reserved.
//

import UIKit

class resultsViewController: UIViewController {

   
    
    @IBOutlet weak var theGif2: UIImageView!
    
    @IBOutlet weak var theGif: UIImageView!
    
    
    @IBOutlet weak var cGif: UIImageView!
    
    
    
    
    
    
    
    @IBOutlet weak var result: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        result.text = String(firstNumber) + " + " + String(secondNumber) + " = " + String(answer)
        
        var imagesNames = ["3.png", "7.png", "15.png", "31.png", "35.png", "39.png", "43.png", "47.png", "51.png", "55.png", "63.png", "66.png"]
        
        var images = [UIImage]()
        
        for i in 0..<imagesNames.count{
            
            images.append(UIImage(named: imagesNames[i])!)
            
            

    }
        
        theGif.animationImages = images
        theGif.animationDuration = 1.5
        theGif.startAnimating()
        
        theGif2.animationImages = images
        theGif2.animationDuration = 1.5
        theGif2.startAnimating()
            
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}