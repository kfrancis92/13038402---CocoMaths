//
//  ViewController.swift
//  cwkMathApp-13038402
//
//  Created by kf13aal on 02/03/2017.
//  Copyright © 2017 kf13aal. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    //@IBOutlet weak var quizLabel1: UILabel!
    
    @IBOutlet weak var questionLabel: UILabel!
    
    @IBOutlet var button0: UIButton!
    @IBOutlet var button1: UIButton!
    @IBOutlet var button2: UIButton!
    @IBOutlet var button3: UIButton!
    @IBOutlet var button4: UIButton!
    @IBOutlet var button5: UIButton!
    @IBOutlet var button6: UIButton!
    @IBOutlet var button7: UIButton!
    @IBOutlet var button8: UIButton!
    @IBOutlet var button9: UIButton!
    
    var CorrectAnswer = String()
    
    
    
    var firstnumber = 0
    var secondnumber = 0
    
    
    
//performSegueWithIdentifier(resultsPage, sender: self)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
       // firstnumber = Int(arc4random_uniform(4))
       // secondnumber = Int(arc4random_uniform(5))
       // quizLabel1.text = String(firstnumber) + " + " + String(secondnumber) + " = "
        // Do any additional setup after loading the view, typically from a nib.
        
        //NSLog("Hello")
        RandomQuestions()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func RandomQuestions(){
        
        let RandomNumber = arc4random() % 4
        
        switch(RandomNumber) {
        case 1:
            
            questionLabel.text = "2 + 6 = "
            button0.setTitle("0", forState: UIControlState.Normal)
            button1.setTitle("1", forState: UIControlState.Normal)
            button2.setTitle("2", forState: UIControlState.Normal)
            button3.setTitle("3", forState: UIControlState.Normal)
            button4.setTitle("4", forState: UIControlState.Normal)
            button5.setTitle("5", forState: UIControlState.Normal)
            button6.setTitle("6", forState: UIControlState.Normal)
            button7.setTitle("7", forState: UIControlState.Normal)
            button8.setTitle("8", forState: UIControlState.Normal)
            button9.setTitle("9", forState: UIControlState.Normal)
            CorrectAnswer = "8"
            break
            
        case 2:
            questionLabel.text = "3 + 4 = "
            button0.setTitle("0", forState: UIControlState.Normal)
            button1.setTitle("1", forState: UIControlState.Normal)
            button2.setTitle("2", forState: UIControlState.Normal)
            button3.setTitle("3", forState: UIControlState.Normal)
            button4.setTitle("4", forState: UIControlState.Normal)
            button5.setTitle("5", forState: UIControlState.Normal)
            button6.setTitle("6", forState: UIControlState.Normal)
            button7.setTitle("7", forState: UIControlState.Normal)
            button8.setTitle("8", forState: UIControlState.Normal)
            button9.setTitle("9", forState: UIControlState.Normal)
            CorrectAnswer = "7"
            break
            
        case 3:
            questionLabel.text = "5 + 4 = "
            button0.setTitle("0", forState: UIControlState.Normal)
            button1.setTitle("1", forState: UIControlState.Normal)
            button2.setTitle("2", forState: UIControlState.Normal)
            button3.setTitle("3", forState: UIControlState.Normal)
            button4.setTitle("4", forState: UIControlState.Normal)
            button5.setTitle("5", forState: UIControlState.Normal)
            button6.setTitle("6", forState: UIControlState.Normal)
            button7.setTitle("7", forState: UIControlState.Normal)
            button8.setTitle("8", forState: UIControlState.Normal)
            button9.setTitle("9", forState: UIControlState.Normal)
            CorrectAnswer = "9"
            break
            
        case 4:
            questionLabel.text = "1 + 2 = "
            button0.setTitle("0", forState: UIControlState.Normal)
            button1.setTitle("1", forState: UIControlState.Normal)
            button2.setTitle("2", forState: UIControlState.Normal)
            button3.setTitle("3", forState: UIControlState.Normal)
            button4.setTitle("4", forState: UIControlState.Normal)
            button5.setTitle("5", forState: UIControlState.Normal)
            button6.setTitle("6", forState: UIControlState.Normal)
            button7.setTitle("7", forState: UIControlState.Normal)
            button8.setTitle("8", forState: UIControlState.Normal)
            button9.setTitle("9", forState: UIControlState.Normal)
            CorrectAnswer = "3"
            break
            
        case 5:
            questionLabel.text = "4 + 2 = "
            button0.setTitle("0", forState: UIControlState.Normal)
            button1.setTitle("1", forState: UIControlState.Normal)
            button2.setTitle("2", forState: UIControlState.Normal)
            button3.setTitle("3", forState: UIControlState.Normal)
            button4.setTitle("4", forState: UIControlState.Normal)
            button5.setTitle("5", forState: UIControlState.Normal)
            button6.setTitle("6", forState: UIControlState.Normal)
            button7.setTitle("7", forState: UIControlState.Normal)
            button8.setTitle("8", forState: UIControlState.Normal)
            button9.setTitle("9", forState: UIControlState.Normal)
            CorrectAnswer = "6"
            break
            
        case 6:
            questionLabel.text = "8 + 1 = "
            button0.setTitle("0", forState: UIControlState.Normal)
            button1.setTitle("1", forState: UIControlState.Normal)
            button2.setTitle("2", forState: UIControlState.Normal)
            button3.setTitle("3", forState: UIControlState.Normal)
            button4.setTitle("4", forState: UIControlState.Normal)
            button5.setTitle("5", forState: UIControlState.Normal)
            button6.setTitle("6", forState: UIControlState.Normal)
            button7.setTitle("7", forState: UIControlState.Normal)
            button8.setTitle("8", forState: UIControlState.Normal)
            button9.setTitle("9", forState: UIControlState.Normal)
            CorrectAnswer = "9"
            break
            
        case 7:
            questionLabel.text = "1 + 1 = "
            button0.setTitle("0", forState: UIControlState.Normal)
            button1.setTitle("1", forState: UIControlState.Normal)
            button2.setTitle("2", forState: UIControlState.Normal)
            button3.setTitle("3", forState: UIControlState.Normal)
            button4.setTitle("4", forState: UIControlState.Normal)
            button5.setTitle("5", forState: UIControlState.Normal)
            button6.setTitle("6", forState: UIControlState.Normal)
            button7.setTitle("7", forState: UIControlState.Normal)
            button8.setTitle("8", forState: UIControlState.Normal)
            button9.setTitle("9", forState: UIControlState.Normal)
            CorrectAnswer = "2"
            break
            
        case 8:
            questionLabel.text = "2 + 1 = "
            button0.setTitle("0", forState: UIControlState.Normal)
            button1.setTitle("1", forState: UIControlState.Normal)
            button2.setTitle("2", forState: UIControlState.Normal)
            button3.setTitle("3", forState: UIControlState.Normal)
            button4.setTitle("4", forState: UIControlState.Normal)
            button5.setTitle("5", forState: UIControlState.Normal)
            button6.setTitle("6", forState: UIControlState.Normal)
            button7.setTitle("7", forState: UIControlState.Normal)
            button8.setTitle("8", forState: UIControlState.Normal)
            button9.setTitle("9", forState: UIControlState.Normal)
            CorrectAnswer = "3"
            break
            
        case 9:
            questionLabel.text = "6 + 3 = "
            button0.setTitle("0", forState: UIControlState.Normal)
            button1.setTitle("1", forState: UIControlState.Normal)
            button2.setTitle("2", forState: UIControlState.Normal)
            button3.setTitle("3", forState: UIControlState.Normal)
            button4.setTitle("4", forState: UIControlState.Normal)
            button5.setTitle("5", forState: UIControlState.Normal)
            button6.setTitle("6", forState: UIControlState.Normal)
            button7.setTitle("7", forState: UIControlState.Normal)
            button8.setTitle("8", forState: UIControlState.Normal)
            button9.setTitle("9", forState: UIControlState.Normal)
            CorrectAnswer = "9"
            break
            
        case 10:
            questionLabel.text = "7 + 2 = "
            button0.setTitle("0", forState: UIControlState.Normal)
            button1.setTitle("1", forState: UIControlState.Normal)
            button2.setTitle("2", forState: UIControlState.Normal)
            button3.setTitle("3", forState: UIControlState.Normal)
            button4.setTitle("4", forState: UIControlState.Normal)
            button5.setTitle("5", forState: UIControlState.Normal)
            button6.setTitle("6", forState: UIControlState.Normal)
            button7.setTitle("7", forState: UIControlState.Normal)
            button8.setTitle("8", forState: UIControlState.Normal)
            button9.setTitle("9", forState: UIControlState.Normal)
            CorrectAnswer = "9"
            break
            
        case 11:
            questionLabel.text = "1 + 4 = "
            button0.setTitle("0", forState: UIControlState.Normal)
            button1.setTitle("1", forState: UIControlState.Normal)
            button2.setTitle("2", forState: UIControlState.Normal)
            button3.setTitle("3", forState: UIControlState.Normal)
            button4.setTitle("4", forState: UIControlState.Normal)
            button5.setTitle("5", forState: UIControlState.Normal)
            button6.setTitle("6", forState: UIControlState.Normal)
            button7.setTitle("7", forState: UIControlState.Normal)
            button8.setTitle("8", forState: UIControlState.Normal)
            button9.setTitle("9", forState: UIControlState.Normal)
            CorrectAnswer = "5"
            break
            
        case 12:
            questionLabel.text = "4 + 2 = "
            button0.setTitle("0", forState: UIControlState.Normal)
            button1.setTitle("1", forState: UIControlState.Normal)
            button2.setTitle("2", forState: UIControlState.Normal)
            button3.setTitle("3", forState: UIControlState.Normal)
            button4.setTitle("4", forState: UIControlState.Normal)
            button5.setTitle("5", forState: UIControlState.Normal)
            button6.setTitle("6", forState: UIControlState.Normal)
            button7.setTitle("7", forState: UIControlState.Normal)
            button8.setTitle("8", forState: UIControlState.Normal)
            button9.setTitle("9", forState: UIControlState.Normal)
            CorrectAnswer = "6"
            break
            
        case 13:
            questionLabel.text = "4 + 4 = "
            button0.setTitle("0", forState: UIControlState.Normal)
            button1.setTitle("1", forState: UIControlState.Normal)
            button2.setTitle("2", forState: UIControlState.Normal)
            button3.setTitle("3", forState: UIControlState.Normal)
            button4.setTitle("4", forState: UIControlState.Normal)
            button5.setTitle("5", forState: UIControlState.Normal)
            button6.setTitle("6", forState: UIControlState.Normal)
            button7.setTitle("7", forState: UIControlState.Normal)
            button8.setTitle("8", forState: UIControlState.Normal)
            button9.setTitle("9", forState: UIControlState.Normal)
            CorrectAnswer = "8"
            break
            
        case 14:
            questionLabel.text = "0 + 0 = "
            button0.setTitle("0", forState: UIControlState.Normal)
            button1.setTitle("1", forState: UIControlState.Normal)
            button2.setTitle("2", forState: UIControlState.Normal)
            button3.setTitle("3", forState: UIControlState.Normal)
            button4.setTitle("4", forState: UIControlState.Normal)
            button5.setTitle("5", forState: UIControlState.Normal)
            button6.setTitle("6", forState: UIControlState.Normal)
            button7.setTitle("7", forState: UIControlState.Normal)
            button8.setTitle("8", forState: UIControlState.Normal)
            button9.setTitle("9", forState: UIControlState.Normal)
            CorrectAnswer = "0"
            break
            
            
        default:
            
            break
            
        }
    }
    
    
    
    @IBAction func ButtonAction0(sender: AnyObject) {
        if(CorrectAnswer == "0") {
            
            NSLog("You are Correct!")
        }
        else {
            NSLog("Wrong Answer!")
            
        }
    }
    
    @IBAction func ButtonAction1(sender: AnyObject) {
        if(CorrectAnswer == "1") {
            NSLog("You are Correct!")
        }
        else {
            NSLog("Wrong Answer!")
        }
    }
    
    @IBAction func ButtonAction2(sender: AnyObject) {
        if(CorrectAnswer == "2") {
            NSLog("You are Correct!")
        }
        else {
            NSLog("Wrong Answer!")
        }
    }
    
    @IBAction func ButtonAction3(sender: AnyObject) {
        if(CorrectAnswer == "3") {
            NSLog("You are Correct!")
        }
        else {
            NSLog("Wrong Answer!")
        }
    }
    
    @IBAction func ButtonAction4(sender: AnyObject) {
        if(CorrectAnswer == "4") {
            NSLog("You are Correct!")
        }
        else {
            NSLog("Wrong Answer!")
        }
    }
    @IBAction func ButtonAction5(sender: AnyObject) {
        if(CorrectAnswer == "5") {
            NSLog("You are Correct!")
        }
        else {
            NSLog("Wrong Answer!")
        }
    }
    @IBAction func ButtonAction6(sender: AnyObject) {
        if(CorrectAnswer == "6") {
            NSLog("You are Correct!")
        }
        else {
            NSLog("Wrong Answer!")
        }
    }
    @IBAction func ButtonAction7(sender: AnyObject) {
        if(CorrectAnswer == "7") {
            NSLog("You are Correct!")
        }
        else {
            NSLog("Wrong Answer!")
        }
    }
    @IBAction func ButtonAction8(sender: AnyObject) {
        if(CorrectAnswer == "8") {
            NSLog("You are Correct!")
        }
        else {
            NSLog("Wrong Answer!")
        }
    }
    @IBAction func ButtonAction9(sender: AnyObject) {
        if(CorrectAnswer == "9") {
            NSLog("You are Correct!")
        }
        else {
            NSLog("Wrong Answer!")
        }
    }
    
    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)
        
    }


}

