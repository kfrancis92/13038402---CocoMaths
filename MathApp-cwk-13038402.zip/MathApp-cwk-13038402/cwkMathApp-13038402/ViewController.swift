//
//  ViewController.swift
//  cwkMathApp-13038402
//
//  Created by kf13aal on 02/03/2017.
//  Copyright © 2017 kf13aal. All rights reserved.
//

import UIKit
var firstNumber = 0
var secondNumber = 0
var answer: Int = 0
var user: Int = 0

class ViewController: UIViewController {
    
    
    @IBOutlet weak var questionLabel: UILabel!
    @IBOutlet weak var answerLabel: UILabel!
    @IBOutlet weak var wrongAnsLabel: UILabel!
    @IBOutlet weak var wrongAnsTxt: UILabel!
    
    
    
    @IBOutlet var button0: UIButton!
    @IBOutlet var button1: UIButton!
    @IBOutlet var button2: UIButton!
    @IBOutlet var button3: UIButton!
    @IBOutlet var button4: UIButton!
    @IBOutlet var button5: UIButton!
    @IBOutlet var button6: UIButton!
    @IBOutlet var button7: UIButton!
    @IBOutlet var button8: UIButton!
    @IBOutlet var button9: UIButton!
    
    

    @IBAction func buttonAction0(sender: UIButton) {
        user = 0
        answerLabel.text = String("0")
        if answer == user {
            performSegueWithIdentifier("resultsPage", sender: self)
        }
        else {
            wrongAnsLabel.text = String("X")
            wrongAnsTxt.text = String("Wrong Answer, try again!")
        }
    }
    
    @IBAction func buttonAction1(sender: UIButton) {
        user = 1
        answerLabel.text = String("1")
        if answer == user {
            performSegueWithIdentifier("resultsPage", sender: self)
        }
        else {
            wrongAnsLabel.text = String("X")
            wrongAnsTxt.text = String("Wrong Answer, try again!")
        }
    }
    
    @IBAction func buttonAction2(sender: UIButton) {
        user = 2
        answerLabel.text = String("2")
        if answer == user {
            performSegueWithIdentifier("resultsPage", sender: self)
        }
        else {
            wrongAnsLabel.text = String("X")
            wrongAnsTxt.text = String("Wrong Answer, try again!")
        }
    }

    @IBAction func buttonAction3(sender: UIButton) {
        user = 3
        answerLabel.text = String("3")
            if answer == user {
             performSegueWithIdentifier("resultsPage", sender: self)
        }
        else {
            wrongAnsLabel.text = String("X")
            wrongAnsTxt.text = String("Wrong Answer, try again!")
        }
    }
    
    @IBAction func buttonAction4(sender: UIButton) {
        user = 4
        answerLabel.text = String("4")
        if answer == user {
            performSegueWithIdentifier("resultsPage", sender: self)
        }
        else {
            wrongAnsLabel.text = String("X")
            wrongAnsTxt.text = String("Wrong Answer, try again!")
        }
    }
    
    @IBAction func buttonAction5(sender: UIButton) {
        user = 5
        answerLabel.text = String("5")
        if answer == user {
            performSegueWithIdentifier("resultsPage", sender: self)
        }
        else {
            wrongAnsLabel.text = String("X")
            wrongAnsTxt.text = String("Wrong Answer, try again!")
        }
    }
    
    @IBAction func buttonAction6(sender: UIButton) {
        user = 6
        answerLabel.text = String("6")
        if answer == user {
            performSegueWithIdentifier("resultsPage", sender: self)
        }
        else {
            wrongAnsLabel.text = String("X")
            wrongAnsTxt.text = String("Wrong Answer, try again!")
        }
    }
    
    @IBAction func buttonAction7(sender: UIButton) {
        user = 7
        answerLabel.text = String("7")
        if answer == user {
            performSegueWithIdentifier("resultsPage", sender: self)
        }
        else {
            wrongAnsLabel.text = String("X")
            wrongAnsTxt.text = String("Wrong Answer, try again!")
        }
    }
    
    @IBAction func buttonAction8(sender: UIButton) {
        user = 8
        answerLabel.text = String("8")
        if answer == user {
            performSegueWithIdentifier("resultsPage", sender: self)
        }
        else {
            wrongAnsLabel.text = String("X")
            wrongAnsTxt.text = String("Wrong Answer, try again!")
        }
    }
    
    @IBAction func buttonAction9(sender: UIButton) {
        user = 9
        answerLabel.text = String("9")
        if answer == user {
            performSegueWithIdentifier("resultsPage", sender: self)
        }
        else {
            wrongAnsLabel.text = String("X")
            wrongAnsTxt.text = String("Wrong Answer, try again!")
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        firstNumber = (Int(arc4random_uniform(5)))
        secondNumber = (Int(arc4random_uniform(5)))
        questionLabel.text = String(firstNumber) + " + " + String(secondNumber) + " ="
        answer = firstNumber + secondNumber
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)
        
    }


}

