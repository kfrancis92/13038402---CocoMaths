//
//  ViewController.swift
//  cwkMathApp-13038402
//
//  Created by kf13aal on 02/03/2017.
//  Copyright © 2017 kf13aal. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var quizLabel1: UILabel!
    
    let W = UIScreen.mainScreen().bounds.width
    let H = UIScreen.mainScreen().bounds.height
    
    var firstnumber = 0
    var secondnumber = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        firstnumber = Int(arc4random_uniform(4))
        secondnumber = Int(arc4random_uniform(5))
        quizLabel1.text = String(firstnumber) + " + " + String(secondnumber) + " ="
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)
        
        
    }


}

