//
//  BounceButton.swift
//  cwkMathApp-13038402
//
//  Created by kf13aal on 21/03/2017.
//  Copyright © 2017 kf13aal. All rights reserved.
//

import UIKit

class BounceButton: UIButton {
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        
        self.transform = CGAffineTransformScale(<#T##t: CGAffineTransform##CGAffineTransform#>, 1.1, 1.1)
        
        UIView.animateWithDuration(<#T##duration: NSTimeInterval##NSTimeInterval#>, animations: <#T##() -> Void#>, completion: <#T##((Bool) -> Void)?##((Bool) -> Void)?##(Bool) -> Void#>)
        
        self.transform = CGAffineTransformIdentity
        
    }
    
    }

