//
//  ViewController.swift
//  Calculator
//
//  Created by kf13aal on 09/02/2017.
//  Copyright © 2017 kf13aal. All rights reserved.
//

import UIKit

var a: Int = 1
var b: Int = 2

class ViewController: UIViewController {
    
    var numberOnScreen: Double = 0
    var previousNum: Double = 0
    var performingMath = false
    var operation = 0
    
    
    @IBOutlet weak var label: UILabel!
    
    @IBAction func Button1(sender: UIButton)
    {
        if performingMath == true
        {
            label.text = String(sender.tag)
            numberOnScreen = Double(label.text!)!
            performingMath = false
        }
        else
        {
            label.text = label.text! + String(sender.tag)
            numberOnScreen = Double(label.text!)!
        }
    }

    @IBAction func buttonPlus(sender: UIButton)
    {
        if label.text != "" && sender.tag != 3 && sender.tag != 4
        {
            previousNum = Double(label.text!)!
            
            if sender.tag == 3
            {
                label.text = "+"
            }
            else if sender.tag == 4
            {
                
            }
            
            operation = sender.tag
            performingMath = true;
        }
        else if sender.tag == 4
        {
            if operation == 3
            {
                label.text = String (previousNum + numberOnScreen)
            }
        }
        
    }
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

